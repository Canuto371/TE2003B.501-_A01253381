#ifndef HAL_UART_H
#define HAL_UART_H

#include "UART_TYPES.h"

void HAL_UART_Init(const UART_Config *config);
void HAL_UART_SendChar(char c);
void HAL_UART_SendString(const char *str);

#endif
