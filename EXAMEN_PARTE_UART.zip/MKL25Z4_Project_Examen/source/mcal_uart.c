#include "MCAL_UART.h"

void MCAL_UART_Init(const UART_Config *config) {
    SIM->SCGC4 |= 0x0400;
    SIM->SCGC5 |= 0x0200;
    //encender reloj

    PORTA->PCR[1] = 0x0200;
    PORTA->PCR[2] = 0x0200;
    //configurar pines

    config->base->C2 = 0;

    config->base->BDH = 0x0F;
    config->base->BDL = 0x1A;

    config->base->C1 = 0;
    //paridad
    if (config->parity == UART_PARITY_EVEN) {
        config->base->C1 |= UART_C1_PE_MASK | UART_C1_PT_MASK;
    } else if (config->parity == UART_PARITY_ODD) {
        config->base->C1 |= UART_C1_PE_MASK;
    }

    config->base->C2 |= 0x08;//trans uart
}

void MCAL_UART_SendChar(UART_Type *base, char c) {
    while (!(base->S1 & 0x80));
    base->D = c;
}
