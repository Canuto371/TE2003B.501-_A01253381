#ifndef MCAL_UART_H
#define MCAL_UART_H

#include "UART_TYPES.h"

void MCAL_UART_Init(const UART_Config *config);
void MCAL_UART_SendChar(UART_Type *base, char c);

#endif
