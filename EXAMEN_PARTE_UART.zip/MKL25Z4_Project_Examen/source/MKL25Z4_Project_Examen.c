#include "HAL_UART.h"
#include "MKL25Z4.h"

int main(void) {
    UART_Config myUartConfig;

    myUartConfig.base = UART0;
    myUartConfig.baud_rate = 115200;
    myUartConfig.parity = UART_PARITY_NONE;
    myUartConfig.stop_bits = UART_STOPBITS;

    HAL_UART_Init(&myUartConfig);

    HAL_UART_SendString("Hi");

    while (1) {
    }
}
