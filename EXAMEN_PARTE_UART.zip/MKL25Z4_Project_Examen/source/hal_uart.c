#include "HAL_UART.h"
#include "MCAL_UART.h"

static UART_Type *hal_uart_base;

void HAL_UART_Init(const UART_Config *config) {
    hal_uart_base = config->base;
    MCAL_UART_Init(config);
}

void HAL_UART_SendChar(char c) {
    MCAL_UART_SendChar(hal_uart_base, c);
}

void HAL_UART_SendString(const char *str) {
    while (*str != '\0') {
        HAL_UART_SendChar(*str);
        str++;
    }
}
