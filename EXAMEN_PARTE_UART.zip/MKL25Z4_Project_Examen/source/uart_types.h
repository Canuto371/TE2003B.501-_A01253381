#ifndef UART_TYPES_H
#define UART_TYPES_H

#include <stdint.h>
#include <MKL25Z4.h> // Incluir MKL25Z4.h para UART0_Type

typedef enum {
    UART_PARITY_NONE,
    UART_PARITY_EVEN,
    UART_PARITY_ODD
} UART_parity;

typedef enum {
    UART_STOPBITS_1,
    UART_STOPBITS_2
} UART_stop_bits;

typedef struct {
    UART0_Type *base; // UART instance (e.g., UART0)
    uint32_t baud_rate; //
    UART_parity parity; //
    UART_stop_bits stop_bits; //
} UART_Config;

#endif
